"""CampusFlow application package."""

